package com.example.anusrees.mymusic;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Song extends AppCompatActivity {
Button bhindi,btamil,benglish,bmalayalam;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song);
        bhindi = (Button) findViewById(R.id.bhindi);
        btamil = (Button) findViewById(R.id.btamil);
        benglish = (Button) findViewById(R.id.benglish);
        bmalayalam = (Button) findViewById(R.id.bmalayalam);
        bhindi.setOnClickListener(new View.OnClickListener() {
    public void onClick(View v) {
        Intent in = new Intent(Song.this, Hindi.class);
        startActivity(in);

    }
});
        benglish.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent in = new Intent(Song.this, English.class);
                startActivity(in);

            }
        });
        bmalayalam.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent in = new Intent(Song.this, Malayalam.class);
                startActivity(in);

            }
        });
        btamil.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent in = new Intent(Song.this,Tamil.class);
                startActivity(in);

            }
        });

    }
}
